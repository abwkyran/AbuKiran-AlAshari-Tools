
# تطبيق أبو كيران العشاري

هذا مشروع أندرويد حقيقي يحتوي على أدوات عائمة، ملاحظات، عدسة، واختصارات.
تم إنشاؤه لدعم Android 11+ ويمكن فتحه عبر Android Studio أو AIDE أو GitHub Replit.

## طريقة التشغيل

- حمّل المشروع
- افتحه على Android Studio أو موقع Replit
- شغّل الأمر: `./gradlew assembleDebug`
- ستجد ملف APK داخل: `app/build/outputs/apk/debug/`
